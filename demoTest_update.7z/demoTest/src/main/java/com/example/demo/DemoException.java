package com.example.demo;

public class DemoException extends Exception {

}
