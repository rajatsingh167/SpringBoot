package com.example.demo;

public interface PersonService {

	  Person johnSmith();

	  String hello(Person person);
	}
