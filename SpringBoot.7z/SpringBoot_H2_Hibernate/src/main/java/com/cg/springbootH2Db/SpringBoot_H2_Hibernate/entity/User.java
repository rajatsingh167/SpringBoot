package com.cg.springbootH2Db.SpringBoot_H2_Hibernate.entity;


public class User {

	private long  id;
	private String name;
	private String role;

	public User() {

	}

	public User(long id,String name, String role) {
		super();
		this.id=id;
		this.name = name;
		this.role = role;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getRole() {
		return role;
	}

	@Override
	public String toString() {
		return String.format("User [id=%s, name=%s, role=%s]", id, name, role);
	}
}