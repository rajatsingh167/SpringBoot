package com.cg.springbootH2Db.SpringBoot_H2_Hibernate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.springbootH2Db.SpringBoot_H2_Hibernate.entity.User;
import com.cg.springbootH2Db.SpringBoot_H2_Hibernate.service.UserJdbcRepository;

@SpringBootApplication
public class SpringBootH2HibernateApplication implements CommandLineRunner{
	@Autowired
	UserJdbcRepository repository;
	
	  private Logger logger = LoggerFactory.getLogger(this.getClass());

	public static void main(String[] args) {
		SpringApplication.run(SpringBootH2HibernateApplication.class, args);
	}

	@Override
	    public void run(String...args) throws Exception {
	        logger.info("User id 10001 -> {}", repository.findById(10001));
	        logger.info("User id 10001 -> {}", repository.findById(10001 ));
	        logger.info("All users 1 -> {}", repository.findAll());
	        logger.info("Inserting -> {}", repository.insert(new User(10010, "John", "A1234657")));
	        logger.info("Update 10001 -> {}", repository.update(new User(10001, "Name-Updated", "New-Passport")));
	        repository.deleteById(10002 );
	    }

}
