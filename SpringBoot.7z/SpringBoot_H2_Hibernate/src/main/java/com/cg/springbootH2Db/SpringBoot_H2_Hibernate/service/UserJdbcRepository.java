package com.cg.springbootH2Db.SpringBoot_H2_Hibernate.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cg.springbootH2Db.SpringBoot_H2_Hibernate.entity.User;

@Repository
public class UserJdbcRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public User findById(long id) {
		return jdbcTemplate.queryForObject("select * from User where id=?", new Object[] { id },
				new BeanPropertyRowMapper<User>(User.class));
	}
	
	class StudentRowMapper implements RowMapper < User > {
	    @Override
	    public User mapRow(ResultSet rs, int rowNum) throws SQLException {
	        User user = new User();
	        user.setId(rs.getLong("id"));
	        user.setName(rs.getString("name"));
	        user.setRole(rs.getString("role"));
	        return user;
	    }
	}
	public List < User > findAll() {
	    return jdbcTemplate.query("select * from User", new StudentRowMapper());
	}

	public int deleteById(long id) {
        return jdbcTemplate.update("delete from User where id=?", new Object[] {
            id
        });
    }
    public int insert(User user) {
        return jdbcTemplate.update("insert into User (id, name, Role) " + "values(?,  ?, ?)",
            new Object[] {
                user.getId(), user.getName(), user.getRole()
            });
    }
    public int update(User user) {
        return jdbcTemplate.update("update User " + " set name = ?, Role = ? " + " where id = ?",
            new Object[] {
                user.getName(), user.getRole(), user.getId()
            });
    }

}
