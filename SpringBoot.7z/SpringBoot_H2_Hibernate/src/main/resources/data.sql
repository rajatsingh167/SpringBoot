insert into User
values(10001,'Ranga', 'E1234567');
insert into User
values(10002,'Ravi', 'A1234568');