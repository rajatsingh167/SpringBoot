package com.cg.springBoot.StudentService;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.springBoot.StudentService.model.Course;
import com.cg.springBoot.StudentService.model.Student;
import com.cg.springBoot.StudentService.service.StudentService;



@RunWith(SpringRunner.class)
@SpringBootTest
public class StudentServiceApplicationTests {

	@Autowired
	StudentService studentService;
	
	@Autowired
	Student actualstudent ;
	@Autowired
	Student  expectedStudent;
	
	
	private static List<Student> students = new ArrayList<>();

	static {
		// Initialize Data
		Course course1 = new Course("Course1", "Spring", "10 Steps",
				Arrays.asList("Learn Maven", "Import Project", "First Example", "Second Example"));
		Course course2 = new Course("Course2", "Spring MVC", "10 Examples",
				Arrays.asList("Learn Maven", "Import Project", "First Example", "Second Example"));
		Course course3 = new Course("Course3", "Spring Boot", "6K Students",
				Arrays.asList("Learn Maven", "Learn Spring", "Learn Spring MVC", "First Example", "Second Example"));
		Course course4 = new Course("Course4", "Maven", "Most popular maven course on internet!",
				Arrays.asList("Pom.xml", "Build Life Cycle", "Parent POM", "Importing into Eclipse"));

		Student rajat = new Student("Student1", "rajat singh", "Hiker, Programmer and Architect",
				new ArrayList<>(Arrays.asList(course1, course2, course3, course4)));

		Student satish = new Student("Student2", "Satish test", "Hiker, Programmer and Architect",
				new ArrayList<>(Arrays.asList(course1, course2, course3, course4)));

		students.add(rajat);
		students.add(satish);
	}
	
	public static Student getStudentbyID(String studentId) {
		for (Student student : students) {
			if (student.getId().equals(studentId)) {
				return student;
			}
		}
		return null;
	}

	@Test
	public void retrieveStudentDetailsForStudent1() {
	
		studentService.retrieveAllStudents();
		System.out.println(studentService.retrieveAllStudents());
		System.out.println("=====================================");
		Assert.assertNotSame(students, studentService.retrieveAllStudents());
	    System.out.println(students);
	}
	
	
	@Test
	public void retrieveStudentByStudentIdforStudent1() {

		String studentId ="Student1";
		expectedStudent=studentService.retrieveStudent(studentId);
		actualstudent = this.getStudentbyID(studentId);
		
		Assert.assertNotSame(expectedStudent, actualstudent);
		
		
	}
	
}
