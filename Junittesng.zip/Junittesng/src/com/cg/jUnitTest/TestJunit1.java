package com.cg.jUnitTest;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import com.cg.java.MessageUtil;

public class TestJunit1 {

	   String message = "Hello World";	
	   MessageUtil messageUtil = new MessageUtil(message);

	   @Test
	   public void testPrintMessage() {
	      assertEquals(message,messageUtil.printMessage());
	   }
}
