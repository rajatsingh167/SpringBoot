package com.cg.jUnitTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestJunit2 {

	   String message = "Robert";	
	   String messageUtil = "Robert";
	   
	   @Test
	   public void testPrintMessage() {	
	      System.out.println("Inside testPrintMessage()");    
	      messageUtil = "hi"+messageUtil;
	     // assertEquals(message,messageUtil );     
	   }
}
